/* *********************************************************************** *
  * project: org.matsim.*
  * ExpBetaPlanChanger.java
  *                                                                         *
  * *********************************************************************** *
  *                                                                         *
  * copyright       : (C) 2007 by the members listed in the COPYING,        *
  *                   LICENSE and WARRANTY file.                            *
  * email           : info at matsim dot org                                *
  *                                                                         *
  * *********************************************************************** *
  *                                                                         *
  *   This program is free software; you can redistribute it and/or modify  *
  *   it under the terms of the GNU General Public License as published by  *
  *   the Free Software Foundation; either version 2 of the License, or     *
  *   (at your option) any later version.                                   *
  *   See also COPYING, LICENSE and WARRANTY file                           *
  *                                                                         *
  * *********************************************************************** */
 
 package org.matsim.core.replanning.selectors;
 
 import org.apache.log4j.Logger;
 import org.matsim.api.core.v01.population.BasicPlan;
 import org.matsim.api.core.v01.population.HasPlansAndId;
 import org.matsim.core.gbl.MatsimRandom;
 
 /**
  * Changes to another plan if that plan is better.  Probability to change depends on score difference.
  *
  * @author kn based on mrieser
  */
 public final class ExpBetaPlanChanger<T extends BasicPlan, I> implements PlanSelector<T, I> {
 	private static final Logger log = Logger.getLogger(ExpBetaPlanChanger.class);
 
 	private final double beta;
 	static boolean betaWrnFlag = true ;
 	static boolean scoreWrnFlag = true ;
 
 	public ExpBetaPlanChanger(double beta) {
 		this.beta = beta;
 	}
 
 
/** This method changes to another plan with a probability proportional to exp scores */
 public T selectPlan(final HasPlansAndId<T, I> person){
   	T selectedPlan = null;
 	double maxScore = Double.NEGATIVE_INFINITY;
 	double minScore = Double.POSITIVE_INFINITY;
 	double sumScore = 0.0;
 	double sumExpScore = 0.0;
 	double sumExpScore2 = 0.0;
 	double expScore;
 	double expScore2;
 	double prob;
 	double random = MatsimRandom.getRandom().nextDouble();
 	double sumProb = 0.0;
 	double sumProb2 = 0.0;
 	double prob2;
 	double random2 = MatsimRandom.getRandom().nextDouble();
 	double sumProb3 = 0.0;
 	double sumProb4 = 0.0;
 	double prob3;
 	double prob4;
 	double random3 = MatsimRandom.getRandom().nextDouble();
 	double random4 = MatsimRandom.getRandom().nextDouble();
 	double sumProb5 = 0.0;
 	double sumProb6 = 0.0;
 	double prob5;
 	double prob6;
 	double random5 = MatsimRandom.getRandom().nextDouble();
 	double random6 = MatsimRandom.getRandom().nextDouble();
 	double sumProb7 = 0.0;
 	double sumProb8 = 0.0;
 	double prob7;
 	double prob8;
 	double random7 = MatsimRandom.getRandom().nextDouble();
 	double random8 = MatsimRandom.getRandom().nextDouble();
 	double sumProb9 = 0.0;
 	double sumProb10 = 0.0;
 	double prob9;
 	double prob10;
 	double random9 = MatsimRandom.getRandom().nextDouble();
 	double random10 = MatsimRandom.getRandom().nextDouble();
 	double sumProb11 = 0.0;
 	double sumProb12 = 0.0;
 	double prob11;
 	double prob12   
 }

                                                            
 }
