package org.matsim.contrib.analysis.spatial;
 
 import org.apache.commons.math3.special.Erf;
 import org.locationtech.jts.geom.Coordinate;
 
 public abstract class SpatialInterpolation {
 
 
/** This uses Gaussian distance weighting to calculate the impact of emissions based on the bond on the centroid of a grid cell. */
 public static double calculateWeightFromLine(final Coordinate from, final Coordinate to, final Coordinate cellCentroid, final double smoothingRadius){
     	double weight = 0.0;
     	double distance = cellCentroid.distance(from);
     	if (distance < smoothingRadius){
     		weight = 1.0 - Erf.erf(Math.sqrt(2.0) * (distance / smoothingRadius));
     	}
     	distance = cellCentroid.distance(to);
     	if (distance < smoothingRadius){
     		weight += 1.0 - Erf.erf(Math.sqrt(2.0) * (distance / smoothingRadius));
     	}
     	return weight;      
 }

                               
     /**
      * This uses an exponential distance weighting to calculate the impact of point based emissions onto the centroid of
      * a grid cell. The calculation is described in Kickhoefer's PhD thesis https://depositonce.tu-berlin.de/handle/11303/4386
      * in Appendix A.2
      *
      * @param emissionSource Centroid of the link
      * @param cellCentroid   Centroid of the impacted cell
      * @return weight factor by which the emission value should be multiplied to calculate the impact of the cell
      */
     @SuppressWarnings("WeakerAccess")
     public static double calculateWeightFromPoint(final Coordinate emissionSource, final Coordinate cellCentroid, double smoothingRadius) {
 
         if (smoothingRadius <= 0)
             throw new IllegalArgumentException("smoothing radius must be greater 0");
         double dist = emissionSource.distance(cellCentroid);
         return Math.exp((-dist * dist) / (smoothingRadius * smoothingRadius));
     }
 }
