/* Copyright (C) 1997-2007  The Chemistry Development Kit (CDK) project
  *                    2009  Egon Willighagen <egonw@users.sf.net>
  *                    2010  Mark Rijnbeek <mark_rynbeek@users.sf.net>
  *
  * Contact: cdk-devel@lists.sourceforge.net
  *
  * This program is free software; you can redistribute it and/or
  * modify it under the terms of the GNU Lesser General Public License
  * as published by the Free Software Foundation; either version 2.1
  * of the License, or (at your option) any later version.
  * All we ask is that proper credit is given for our work, which includes
  * - but is not limited to - adding the above copyright notice to the beginning
  * of your source code files, and to any copyright notice that you may distribute
  * with programs based on this work.
  *
  * This program is distributed in the hope that it will be useful,
  * but WITHOUT ANY WARRANTY; without even the implied warranty of
  * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  * GNU Lesser General Public License for more details.
  *
  * You should have received a copy of the GNU Lesser General Public License
  * along with this program; if not, write to the Free Software
  * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA.
  */
 package org.openscience.cdk.io;
 
 import org.openscience.cdk.AtomRef;
 import org.openscience.cdk.CDKConstants;
 import org.openscience.cdk.config.Elements;
 import org.openscience.cdk.config.Isotopes;
 import org.openscience.cdk.exception.CDKException;
 import org.openscience.cdk.interfaces.IAtom;
 import org.openscience.cdk.interfaces.IAtomContainer;
 import org.openscience.cdk.interfaces.IBond;
 import org.openscience.cdk.interfaces.IChemFile;
 import org.openscience.cdk.interfaces.IChemModel;
 import org.openscience.cdk.interfaces.IChemObject;
 import org.openscience.cdk.interfaces.IChemSequence;
 import org.openscience.cdk.interfaces.IIsotope;
 import org.openscience.cdk.interfaces.IPseudoAtom;
 import org.openscience.cdk.interfaces.IStereoElement;
 import org.openscience.cdk.interfaces.ITetrahedralChirality;
 import org.openscience.cdk.io.formats.IResourceFormat;
 import org.openscience.cdk.io.formats.MDLFormat;
 import org.openscience.cdk.io.setting.BooleanIOSetting;
 import org.openscience.cdk.io.setting.IOSetting;
 import org.openscience.cdk.io.setting.StringIOSetting;
 import org.openscience.cdk.isomorphism.matchers.Expr;
 import org.openscience.cdk.isomorphism.matchers.IQueryAtom;
 import org.openscience.cdk.isomorphism.matchers.QueryAtom;
 import org.openscience.cdk.isomorphism.matchers.QueryBond;
 import org.openscience.cdk.sgroup.Sgroup;
 import org.openscience.cdk.sgroup.SgroupBracket;
 import org.openscience.cdk.sgroup.SgroupKey;
 import org.openscience.cdk.tools.ILoggingTool;
 import org.openscience.cdk.tools.LoggingToolFactory;
 import org.openscience.cdk.tools.manipulator.AtomContainerManipulator;
 import org.openscience.cdk.tools.manipulator.ChemFileManipulator;
 
 import java.io.BufferedWriter;
 import java.io.IOException;
 import java.io.OutputStream;
 import java.io.OutputStreamWriter;
 import java.io.StringWriter;
 import java.io.Writer;
 import java.nio.charset.StandardCharsets;
 import java.text.NumberFormat;
 import java.text.SimpleDateFormat;
 import java.util.AbstractMap;
 import java.util.ArrayList;
 import java.util.Arrays;
 import java.util.Collection;
 import java.util.EnumSet;
 import java.util.HashMap;
 import java.util.Iterator;
 import java.util.LinkedHashMap;
 import java.util.List;
 import java.util.Locale;
 import java.util.Map;
 import java.util.Set;
 import java.util.TreeMap;
 import java.util.regex.Matcher;
 import java.util.regex.Pattern;
 import java.util.stream.Collectors;
 
 /**
  * Writes MDL molfiles, which contains a single molecule (see {@cdk.cite DAL92}).
  * For writing a MDL molfile you can this code:
  * <pre>
  * MDLV2000Writer writer = new MDLV2000Writer(
  *   new FileWriter(new File("output.mol"))
  * );
  * writer.write((IAtomContainer)molecule);
  * writer.close();
  * </pre>
  * 
  * <p>The writer has two IO settings: one for writing 2D coordinates, even if
  * 3D coordinates are given for the written data; the second writes aromatic
  * bonds as bond type 4, which is, strictly speaking, a query bond type, but
  * my many tools used to reflect aromaticity. The full IO setting API is
  * explained in CDK News {@cdk.cite WILLIGHAGEN2004}. One programmatic option
  * to set the option for writing 2D coordinates looks like:
  * <pre>
  * Properties customSettings = new Properties();
  * customSettings.setProperty(
  *  "ForceWriteAs2DCoordinates", "true"
  * );
  * PropertiesListener listener =
  *   new PropertiesListener(customSettings);
  * writer.addChemObjectIOListener(listener);
  * </pre>
  *
  * @cdk.module io
  * @cdk.githash
  * @cdk.iooptions
  * @cdk.keyword file format, MDL molfile
  */
 public class MDLV2000Writer extends DefaultChemObjectWriter {
 
     public static final String OptForceWriteAs2DCoordinates = "ForceWriteAs2DCoordinates";
     public static final String OptWriteMajorIsotopes        = "WriteMajorIsotopes";
     public static final String OptWriteAromaticBondTypes    = "WriteAromaticBondTypes";
     public static final String OptWriteQueryFormatValencies = "WriteQueryFormatValencies";
     public static final String OptWriteDefaultProperties    = "WriteDefaultProperties";
     public static final String OptProgramName               = "ProgramName";
 
     private final static ILoggingTool logger = LoggingToolFactory.createLoggingTool(MDLV2000Writer.class);
 
     // regular expression to capture R groups with attached numbers
     private Pattern NUMERED_R_GROUP = Pattern.compile("R(\\d+)");
 
     /**
      * Enumeration of all valid radical values.
      */
     public enum SPIN_MULTIPLICITY {
 
         None(0, 0),
         Monovalent(2, 1),
         DivalentSinglet(1, 2),
         DivalentTriplet(3, 2);
 
         // the radical SDF value
         private final int value;
         // the corresponding number of single electrons
         private final int singleElectrons;
 
         private SPIN_MULTIPLICITY(int value, int singleElectrons) {
             this.value = value;
             this.singleElectrons = singleElectrons;
         }
 
         /**
          * Radical value for the spin multiplicity in the properties block.
          *
          * @return the radical value
          */
         public int getValue() {
             return value;
         }
 
         /**
          * The number of single electrons that correspond to the spin multiplicity.
          *
          * @return the number of single electrons
          */
         public int getSingleElectrons() {
             return singleElectrons;
         }
 
         /**
          * Create a SPIN_MULTIPLICITY instance for the specified value.
          *
          * @param value input value (in the property block)
          * @return instance
          * @throws CDKException unknown spin multiplicity value
          */
         public static SPIN_MULTIPLICITY ofValue(int value) throws CDKException {
             switch (value) {
                 case 0:
                     return None;
                 case 1:
                     return DivalentSinglet;
                 case 2:
                     return Monovalent;
                 case 3:
                     return DivalentTriplet;
                 default:
                     throw new CDKException("unknown spin multiplicity: " + value);
             }
         }
     }
 
     // number of entries on line; value = 1 to 8
     private static final int NN8   = 8;
     // spacing between entries on line
     private static final int WIDTH = 3;
 
     private BooleanIOSetting forceWriteAs2DCoords;
 
     private BooleanIOSetting writeMajorIsotopes;
 
     // The next two options are MDL Query format options, not really
     // belonging to the MDLV2000 format, and will be removed when
     // a MDLV2000QueryWriter is written.
 
     /*
      * Should aromatic bonds be written as bond type 4? If true, this makes the
      * output a query file.
      */
     private BooleanIOSetting writeAromaticBondTypes;
 
     /* Should atomic valencies be written in the Query format. */
     @Deprecated
     private BooleanIOSetting writeQueryFormatValencies;
 
     private BooleanIOSetting writeDefaultProps;
 
     private StringIOSetting programNameOpt;
 
     private BufferedWriter writer;
 
     /**
      * Constructs a new MDLWriter that can write an {@link IAtomContainer}
      * to the MDL molfile format.
      *
      * @param out The Writer to write to
      */
     public MDLV2000Writer(Writer out) {
         if (out instanceof BufferedWriter) {
             writer = (BufferedWriter) out;
         } else {
             writer = new BufferedWriter(out);
         }
         initIOSettings();
     }
 
     /**
      * Constructs a new MDLWriter that can write an {@link IAtomContainer}
      * to a given OutputStream.
      *
      * @param output The OutputStream to write to
      */
     public MDLV2000Writer(OutputStream output) {
         this(new OutputStreamWriter(output, StandardCharsets.UTF_8));
     }
 
     public MDLV2000Writer() {
         this(new StringWriter());
     }
 
     @Override
     public IResourceFormat getFormat() {
         return MDLFormat.getInstance();
     }
 
     @Override
     public void setWriter(Writer out) throws CDKException {
         if (out instanceof BufferedWriter) {
             writer = (BufferedWriter) out;
         } else {
             writer = new BufferedWriter(out);
         }
     }
 
     @Override
     public void setWriter(OutputStream output) throws CDKException {
         setWriter(new OutputStreamWriter(output));
     }
 
     /**
      * Flushes the output and closes this object.
      */
     @Override
     public void close() throws IOException {
         writer.close();
     }
 
     @Override
     public boolean accepts(Class<? extends IChemObject> classObject) {
         Class<?>[] interfaces = classObject.getInterfaces();
         for (int i = 0; i < interfaces.length; i++) {
             if (IAtomContainer.class.equals(interfaces[i])) return true;
             if (IChemFile.class.equals(interfaces[i])) return true;
             if (IChemModel.class.equals(interfaces[i])) return true;
         }
         if (IAtomContainer.class.equals(classObject)) return true;
         if (IChemFile.class.equals(classObject)) return true;
         if (IChemModel.class.equals(classObject)) return true;
         Class superClass = classObject.getSuperclass();
         if (superClass != null) return this.accepts(superClass);
         return false;
     }
 
     /**
      * Writes a {@link IChemObject} to the MDL molfile formated output.
      * It can only output ChemObjects of type {@link IChemFile},
      * {@link IChemObject} and {@link IAtomContainer}.
      *
      * @param object {@link IChemObject} to write
      * @see #accepts(Class)
      */
     @Override
     public void write(IChemObject object) throws CDKException {
         customizeJob();
         try {
             if (object instanceof IChemFile) {
                 writeChemFile((IChemFile) object);
                 return;
             } else if (object instanceof IChemModel) {
                 IChemFile file = object.getBuilder().newInstance(IChemFile.class);
                 IChemSequence sequence = object.getBuilder().newInstance(IChemSequence.class);
                 sequence.addChemModel((IChemModel) object);
                 file.addChemSequence(sequence);
                 writeChemFile((IChemFile) file);
                 return;
             } else if (object instanceof IAtomContainer) {
                 writeMolecule((IAtomContainer) object);
                 return;
             }
         } catch (Exception ex) {
             logger.error(ex.getMessage());
             logger.debug(ex);
             throw new CDKException("Exception while writing MDL file: " + ex.getMessage(), ex);
         }
         throw new CDKException("Only supported is writing of IChemFile, " + "IChemModel, and IAtomContainer objects.");
     }
 
     private void writeChemFile(IChemFile file) throws Exception {
         IAtomContainer bigPile = file.getBuilder().newInstance(IAtomContainer.class);
         for (IAtomContainer container : ChemFileManipulator.getAllAtomContainers(file)) {
             bigPile.add(container);
             if (container.getTitle() != null) {
                 if (bigPile.getTitle() != null)
                     bigPile.setTitle(bigPile.getTitle() + "; " + container.getTitle());
                 else
                     bigPile.setTitle(container.getTitle());
             }
             if (container.getProperty(CDKConstants.REMARK) != null) {
                 if (bigPile.getProperty(CDKConstants.REMARK) != null)
                     bigPile.setProperty(CDKConstants.REMARK, bigPile.getProperty(CDKConstants.REMARK) + "; "
                                                              + container.getProperty(CDKConstants.REMARK));
                 else
                     bigPile.setProperty(CDKConstants.REMARK, container.getProperty(CDKConstants.REMARK));
             }
         }
         writeMolecule(bigPile);
     }
 
     private String getProgName() {
         String progname = programNameOpt.getSetting();
         if (progname == null)
             return "        ";
         else if (progname.length() > 8)
             return progname.substring(0, 8);
         else if (progname.length() < 8)
             return String.format("%-8s", progname);
         else
             return progname;
     }
 
 
/** A molecule is written to an output stream. */
 public void writeMolecule(IAtomContainer container) throws Exception{}

                                                                                                                                                                                                                                                                                                                                                                                                                                                          
     /**
      * Determines the chiral flag, a molecule is chiral if all it's tetrahedral stereocenters are marked as absolute.
      * This function also checks if there is enhanced stereochemistry that cannot be emitted (without information loss)
      * in V2000.
      *
      * @param stereo tetrahedral stereo
      * @return the chiral status
      */
     static boolean getChiralFlag(Iterable<? extends IStereoElement> stereo) {
         boolean chiral = true;
         int seenGrpInfo = 0;
         int numTetrahedral = 0;
         for (IStereoElement tc : stereo) {
             if (tc.getConfigClass() != IStereoElement.TH)
                 continue;
             numTetrahedral++;
             if (tc.getGroupInfo() != IStereoElement.GRP_ABS) {
                 if (seenGrpInfo == 0) {
                     seenGrpInfo = tc.getGroupInfo();
                 } else if (seenGrpInfo != tc.getGroupInfo()) {
                     // we could check for racemic only but V2000 originally didn't differentiate between relative
                     // or racemic so providing they're all the same it's okay. But we should warn if there is something
                     // more complicated
                     logger.warn("Molecule has enhanced stereochemistry that cannot be represented in V2000");
                 }
                 chiral = false;
             }
         }
         if (numTetrahedral == 0)
             chiral = false;
         return chiral;
     }
 
 
     private static void writeAtomLists(Map<Integer, IAtom> atomLists, BufferedWriter writer) throws IOException {
         //write out first as the legacy atom list way and then as the M  ALS way
         //since there should only be a few lines to write each way
         //it's easier to write them out in one pass through our Map
         // and save the lines to write into temp Lists to write out at the end.
         List<String> legacyLines = new ArrayList<>(atomLists.size());
         List<String> alsLines = new ArrayList<>(atomLists.size());
 
         for(Map.Entry<Integer, IAtom> entry : atomLists.entrySet()){
             QueryAtom qa = (QueryAtom) AtomRef.deref(entry.getValue());
             //atom lists are limited to just a list of ELEMENTS OR'ed together
             //with the whole expression possibly negated
 
             Expr expression = qa.getExpression();
             List<String> elements=getAtomList(expression);
             StringBuilder legacyBuilder = new StringBuilder(80);
             StringBuilder alsBuilder = new StringBuilder(80);
             alsBuilder.append("M  ALS ");
             alsBuilder.append(formatMDLInt(entry.getKey()+1, 3));
             alsBuilder.append(formatMDLInt(elements.size(), 3));
 
             legacyBuilder.append(formatMDLInt(entry.getKey()+1, 3));
             //root expression type is either OR or NOT
             if(expression.type() == Expr.Type.NOT){
                 alsBuilder.append(" T ");
                 legacyBuilder.append(" T    ");
             }else {
                 alsBuilder.append(" F ");
                 legacyBuilder.append(" F    ");
             }
             for(String symbol : elements){
                 alsBuilder.append(formatMDLString(symbol, 4));
             }
             legacyBuilder.append(formatMDLInt(elements.size(), 1));
             for(Integer atomicNumber : getAtomListNumbers(expression)){
                 legacyBuilder.append(" ").append(formatMDLInt(atomicNumber, 3));
             }
             alsBuilder.append('\n');
             legacyBuilder.append('\n');
 
             alsLines.add(alsBuilder.toString());
             legacyLines.add(legacyBuilder.toString());
         }
         for(String line: legacyLines){
             writer.write(line);
         }
         for(String line: alsLines){
             writer.write(line);
         }
     }
 
     private static boolean isValidAtomListExpression(Expr exp){
 
         Expr rootToCheck;
         if(Expr.Type.NOT==exp.type()){
             rootToCheck = exp.left();
         }else if(Expr.Type.OR==exp.type()){
             rootToCheck = exp;
         }else{
             //not a list
             return false;
         }
         Set<Expr.Type> allowedTypes = EnumSet.of(Expr.Type.ELEMENT, Expr.Type.ALIPHATIC_ELEMENT, Expr.Type.AROMATIC_ELEMENT);
 
         return allOrsOfAllowedTypes(rootToCheck, allowedTypes);
     }
     private static boolean allOrsOfAllowedTypes(Expr expr, Set<Expr.Type> allowedTypes){
         if(expr.type() == Expr.Type.OR){
             return allOrsOfAllowedTypes(expr.left(), allowedTypes) && allOrsOfAllowedTypes(expr.right(), allowedTypes);
         }
         return allowedTypes.contains(expr.type());
     }
 
     private static List<String> getAtomList(Expr exp){
         List<Expr> elist = new ArrayList<>();
         getLeafNodes(exp, elist);
         return elist.stream().map(expr->Elements.ofNumber(expr.value()).symbol())
                     .collect(Collectors.toList());
 
     }
     private static List<Integer> getAtomListNumbers(Expr exp){
         List<Expr> elist = new ArrayList<>();
         getLeafNodes(exp, elist);
         return elist.stream().map(Expr::value)
                 .collect(Collectors.toList());
 
     }
 
     private static void getLeafNodes(Expr exr, List<Expr> elist){
         if(exr.type().equals(Expr.Type.OR) || exr.type().equals(Expr.Type.AND)){
             getLeafNodes(exr.left(), elist);
             getLeafNodes(exr.right(), elist);
         }else if(exr.type().equals(Expr.Type.NOT)){
             getLeafNodes(exr.left(), elist);
         }else{
             elist.add(exr);
         }
     }
     // 0 = uncharged or value other than these, 1 = +3, 2 = +2, 3 = +1,
     // 4 = doublet radical, 5 = -1, 6 = -2, 7 = -3
     private int determineCharge(IAtomContainer mol, IAtom atom) {
         Integer q = atom.getFormalCharge();
         if (q == null)
             q = 0;
         switch (q) {
             case -3: return 7;
             case -2: return 6;
             case -1: return 5;
             case 0:
                 if (mol.getConnectedSingleElectronsCount(atom) == 1)
                     return 4;
                 return 0;
             case +1:  return 3;
             case +2:  return 2;
             case +3:  return 1;
         }
         return 0;
     }
 
     private int determineIsotope(IAtom atom) {
         Integer  mass  = atom.getMassNumber();
         IIsotope major = null;
         if (mass == null)
             return 0;
         try {
             major = Isotopes.getInstance().getMajorIsotope(atom.getSymbol());
         } catch (IOException e) {
             // ignored
         }
         if (!writeMajorIsotopes.isSet() &&
             major != null &&
             mass.equals(major.getMassNumber()))
             mass = null;
         if (mass != null) {
             mass -= major != null ? major.getMassNumber() : 0;
             return mass >= -3 && mass <= 4 ? mass : 0;
         } return 0;
     }
 
     private int determineAtomMap(IAtom atom) {
         Object amap   = atom.getProperty(CDKConstants.ATOM_ATOM_MAPPING);
         if (amap == null)
             return 0;
         if (amap instanceof Integer)
             return (Integer) amap;
         else {
             if (amap instanceof String) {
                 try {
                     return Integer.parseInt((String) amap);
                 } catch (NumberFormatException ex) {
                     //ignored
                 }
             }
             logger.warn("Skipping non-integer atom map: " + amap +
                         " type:" + amap);
             return 0;
         }
     }
 
     private int determineValence(IAtomContainer container, IAtom atom) {
         int explicitValence = (int) AtomContainerManipulator.getBondOrderSum(container, atom);
         int charge = atom.getFormalCharge() == null ? 0 : atom.getFormalCharge();
         Integer element = atom.getAtomicNumber();
         int valence = 0;
 
         if (element != null) {
             int implied = MDLValence.implicitValence(element, charge, explicitValence);
             int actual;
             if (atom.getImplicitHydrogenCount() != null)
                 actual = explicitValence + atom.getImplicitHydrogenCount();
             else if (atom.getValency() != null)
                 actual = atom.getValency();
             else
                 return 0;
             if (implied != actual) {
                 if (actual == 0)
                     return 15;
                 else if (actual > 0 && actual < 15)
                     return actual;
             }
         }
         return valence;
     }
 
     private int determineStereoParity(IAtomContainer container,
                                       Map<IAtom, ITetrahedralChirality> atomstereo,
                                       Map<IAtom, Integer> atomindex, IAtom atom) {
         final ITetrahedralChirality tc = atomstereo.get(atom);
         if (tc == null)
             return 0;
         int parity = tc.getStereo() == ITetrahedralChirality.Stereo.CLOCKWISE ? 1 : 2;
         IAtom   focus    = tc.getChiralAtom();
         IAtom[] carriers = tc.getLigands();
 
         int hidx = -1;
         for (int i = 0; i < 4; i++) {
             // hydrogen position
             if (carriers[i].equals(focus) || carriers[i].getAtomicNumber() == 1) {
                 if (hidx >= 0) parity = 0;
                 hidx = i;
             }
         }
 
         if (parity != 0) {
             for (int i = 0; i < 4; i++) {
                 for (int j = i + 1; j < 4; j++) {
                     int a = atomindex.get(carriers[i]);
                     int b = atomindex.get(carriers[j]);
                     if (i == hidx)
                         a = container.getAtomCount();
                     if (j == hidx)
                         b = container.getAtomCount();
                     if (a > b)
                         parity ^= 0x3;
                 }
             }
         }
         return parity;
     }
 
     private boolean isMajorIsotope(IAtom atom)  {
         if (atom.getMassNumber() == null)
             return false;
         try {
             IIsotope major = Isotopes.getInstance().getMajorIsotope(atom.getSymbol());
             return major != null && major.getMassNumber().equals(atom.getMassNumber());
         } catch (IOException ex) {
             return false;
         }
     }
 
     private void writeSgroups(IAtomContainer container, BufferedWriter writer, Map<IAtom,Integer> atomidxs) throws IOException {
         List<Sgroup> sgroups = container.getProperty(CDKConstants.CTAB_SGROUPS);
         if (sgroups == null)
             return;
 
         // going to modify
         sgroups = new ArrayList<>(sgroups);
 
 
         // remove non-ctab Sgroups
         sgroups.removeIf(sgroup -> !sgroup.getType().isCtabStandard());
 
         List<Map.Entry<Sgroup,Sgroup>> parentList = new ArrayList<>();
 
         // collect parents
         for (Sgroup sgroup : sgroups) {
             for (Sgroup parent : sgroup.getParents())
                 parentList.add(new AbstractMap.SimpleEntry<>(sgroup, parent));
         }
 
         for (List<Sgroup> wrapSgroups : wrap(sgroups, 8)) {
             // Declare the SGroup type
             writer.write("M  STY");
             writer.write(formatMDLInt(wrapSgroups.size(), 3));
             for (Sgroup sgroup : wrapSgroups) {
                 writer.write(' ');
                 writer.write(formatMDLInt(1 + sgroups.indexOf(sgroup), 3));
                 writer.write(' ');
                 writer.write(sgroup.getType().getKey());
             }
             writer.write('\n');
         }
 
         // Sgroup Parent List
         for (List<Map.Entry<Sgroup,Sgroup>> parents : wrap(parentList, 8)) {
             writer.write("M  SPL");
             writer.write(formatMDLInt(parents.size(), 3));
             for (Map.Entry<Sgroup,Sgroup> e : parents) {
                 writer.write(' ');
                 writer.write(formatMDLInt(1+sgroups.indexOf(e.getKey()), 3));
                 writer.write(' ');
                 writer.write(formatMDLInt(1+sgroups.indexOf(e.getValue()), 3));
             }
             writer.write('\n');
         }
 
         // Sgroup output is non-compact for now - but valid
         for (int id = 1; id <= sgroups.size(); id++) {
             Sgroup sgroup = sgroups.get(id - 1);
 
             // Sgroup Atom List
             for (List<IAtom> atoms : wrap(sgroup.getAtoms(), 15)) {
                 writer.write("M  SAL ");
                 writer.write(formatMDLInt(id, 3));
                 writer.write(formatMDLInt(atoms.size(), 3));
                 for (IAtom atom : atoms) {
                     writer.write(' ');
                     writer.write(formatMDLInt(1+atomidxs.get(atom), 3));
                 }
                 writer.write('\n');
             }
 
             // Sgroup Bond List
             for (List<IBond> bonds : wrap(sgroup.getBonds(), 15)) {
                 writer.write("M  SBL ");
                 writer.write(formatMDLInt(id, 3));
                 writer.write(formatMDLInt(bonds.size(), 3));
                 for (IBond bond : bonds) {
                     writer.write(' ');
                     writer.write(formatMDLInt(1+container.indexOf(bond), 3));
                 }
                 writer.write('\n');
             }
 
             Set<SgroupKey> attributeKeys = sgroup.getAttributeKeys();
             // TODO order and aggregate attribute keys
             for (SgroupKey key : attributeKeys) {
                 switch (key) {
                     case CtabSubScript:
                         writer.write("M  SMT ");
                         writer.write(formatMDLInt(id, 3));
                         writer.write(' ');
                         writer.write((String) sgroup.getValue(key));
                         writer.write('\n');
                         break;
                     case CtabExpansion:
                         final boolean expanded = sgroup.getValue(key);
                         if (expanded) {
                             writer.write("M  SDS EXP");
                             writer.write(formatMDLInt(1, 3));
                             writer.write(' ');
                             writer.write(formatMDLInt(id, 3));
                             writer.write('\n');
                         }
                         break;
                     case CtabBracket:
                         final List<SgroupBracket> brackets = sgroup.getValue(key);
                         for (SgroupBracket bracket : brackets) {
                             writer.write("M  SDI ");
                             writer.write(formatMDLInt(id, 3));
                             writer.write(formatMDLInt(4, 3));
                             writer.write(formatMDLFloat((float) bracket.getFirstPoint().x));
                             writer.write(formatMDLFloat((float) bracket.getFirstPoint().y));
                             writer.write(formatMDLFloat((float) bracket.getSecondPoint().x));
                             writer.write(formatMDLFloat((float) bracket.getSecondPoint().y));
                             writer.write('\n');
                         }
                         break;
                     case CtabBracketStyle:
                         writer.write("M  SBT");
                         writer.write(formatMDLInt(1, 3));
                         writer.write(' ');
                         writer.write(formatMDLInt(id, 3));
                         writer.write(' ');
                         writer.write(formatMDLInt((int)sgroup.getValue(key), 3));
                         writer.write('\n');
                         break;
                     case CtabConnectivity:
                         writer.write("M  SCN");
                         writer.write(formatMDLInt(1, 3));
                         writer.write(' ');
                         writer.write(formatMDLInt(id, 3));
                         writer.write(' ');
                         writer.write(((String) sgroup.getValue(key)).toUpperCase(Locale.ROOT));
                         writer.write('\n');
                         break;
                     case CtabSubType:
                         writer.write("M  SST");
                         writer.write(formatMDLInt(1, 3));
                         writer.write(' ');
                         writer.write(formatMDLInt(id, 3));
                         writer.write(' ');
                         writer.write((String) sgroup.getValue(key));
                         writer.write('\n');
                         break;
                     case CtabParentAtomList:
                         Collection<IAtom> parentAtomList = sgroup.getValue(key);
                         for (List<IAtom> atoms : wrap(parentAtomList, 15)) {
                             writer.write("M  SPA ");
                             writer.write(formatMDLInt(id, 3));
                             writer.write(formatMDLInt(atoms.size(), 3));
                             for (IAtom atom : atoms) {
                                 writer.write(' ');
                                 writer.write(formatMDLInt(1+atomidxs.get(atom), 3));
                             }
                             writer.write('\n');
                         }
                         break;
                     case CtabComponentNumber:
                         Integer compNumber = sgroup.getValue(key);
                         writer.write("M  SNC");
                         writer.write(formatMDLInt(1, 3));
                         writer.write(' ');
                         writer.write(formatMDLInt(id, 3));
                         writer.write(' ');
                         writer.write(formatMDLInt(compNumber, 3));
                         writer.write('\n');
                         break;
                     case Data:
                         String data = sgroup.getValue(SgroupKey.Data);
                         if (data == null)
                             break;
                         // replace CR/LF with space
                         data = data.replaceAll("[\r\n]", " ");
                         while (data.length() > 69) {
                             writer.write("M  SCD ");
                             writer.write(formatMDLInt(id, 3));
                             writer.write(' ');
                             writer.write(data.substring(0, 69));
                             writer.write('\n');
                             data = data.substring(69);
                         }
                         writer.write("M  SED ");
                         writer.write(formatMDLInt(id, 3));
                         writer.write(' ');
                         writer.write(data);
                         writer.write('\n');
                         break;
                     case DataFieldName:
                         char[] pad = new char[30];
                         Arrays.fill(pad, ' ');
                         String name = sgroup.getValue(SgroupKey.DataFieldName);
                         String fmt = sgroup.getValue(SgroupKey.DataFieldFormat);
                         String units = sgroup.getValue(SgroupKey.DataFieldUnits);
                         if (name == null)
                             break;
                         if (name.length() > 30)
                             name = name.substring(0, 30);
                         writer.write("M  SDT ");
                         writer.write(formatMDLInt(id, 3));
                         writer.write(' ');
                         writer.write(name);
                         writer.write(pad, 0, 30-name.length());
                         if (fmt != null && fmt.length()>0 &&
                             (fmt.charAt(0) == 'N' ||
                              fmt.charAt(0) == 'F' ||
                              fmt.charAt(0) == 'T')) {
                             writer.write(fmt.charAt(0) + " ");
                         } else {
                             writer.write("  ");
                         }
                         if (units != null) {
                             if (units.length() > 20)
                                 units = units.substring(0, 20);
                             writer.write(units);
                         }
                         writer.write('\n');
                         break;
                     case DataFieldFormat:
                     case DataFieldUnits:
                         // written as part of the field name
                         break;
                 }
             }
 
         }
     }
 
     private <T> List<List<T>> wrap(Collection<T> set, int lim) {
         List<List<T>> wrapped = new ArrayList<>();
         List<T> list = new ArrayList<T>(set);
         if (set.size() <= lim) {
             if (!list.isEmpty())
              wrapped.add(list);
         } else {
             int i = 0;
             for (; (i + lim) < set.size(); i += lim) {
                 wrapped.add(list.subList(i, i + lim));
             }
             wrapped.add(list.subList(i, list.size()));
         }
         return wrapped;
     }
 
     private int getNumberOfDimensions(IAtomContainer mol) {
         for (IAtom atom : mol.atoms()) {
             if (atom.getPoint3d() != null && !forceWriteAs2DCoords.isSet())
                 return 3;
             else if (atom.getPoint2d() != null)
                 return 2;
         }
         return 0;
     }
 
     private void writeRadicalPattern(Iterator<Map.Entry<Integer, SPIN_MULTIPLICITY>> iterator, int i)
             throws IOException {
 
         Map.Entry<Integer, SPIN_MULTIPLICITY> entry = iterator.next();
         writer.write(" ");
         writer.write(formatMDLInt(entry.getKey() + 1, WIDTH));
         writer.write(" ");
         writer.write(formatMDLInt(entry.getValue().getValue(), WIDTH));
 
         i = i + 1;
         if (i < NN8 && iterator.hasNext()) writeRadicalPattern(iterator, i);
     }
 
     /**
      * Formats an integer to fit into the connection table and changes it
      * to a String.
      *
      * @param x The int to be formated
      * @param n Length of the String
      * @return The String to be written into the connectiontable
      */
     protected static String formatMDLInt(int x, int n) {
         char[] buf = new char[n];
         Arrays.fill(buf, ' ');
         String val = Integer.toString(x);
         if (val.length() > n)
             val = "0";
         int off = n - val.length();
         for (int i = 0; i < val.length(); i++)
             buf[off+i] = val.charAt(i);
         return new String(buf);
     }
 
     /**
      * Formats a float to fit into the connectiontable and changes it
      * to a String.
      *
      * @param fl The float to be formated
      * @return The String to be written into the connectiontable
      */
     protected static String formatMDLFloat(float fl) {
         String s = "", fs = "";
         int l;
         NumberFormat nf = NumberFormat.getNumberInstance(Locale.ENGLISH);
         nf.setMinimumIntegerDigits(1);
         nf.setMaximumIntegerDigits(4);
         nf.setMinimumFractionDigits(4);
         nf.setMaximumFractionDigits(4);
         nf.setGroupingUsed(false);
         if (Double.isNaN(fl) || Double.isInfinite(fl))
             s = "0.0000";
         else
             s = nf.format(fl);
         l = 10 - s.length();
         for (int f = 0; f < l; f++)
             fs += " ";
         fs += s;
         return fs;
     }
 
     /**
      * Formats a String to fit into the connectiontable.
      *
      * @param s  The String to be formated
      * @param le The length of the String
      * @return The String to be written in the connectiontable
      */
     protected static String formatMDLString(String s, int le) {
         s = s.trim();
         if (s.length() > le) return s.substring(0, le);
         int l;
         l = le - s.length();
         for (int f = 0; f < l; f++)
             s += " ";
         return s;
     }
 
     /**
      * Initializes IO settings.<br>
      * Please note with regards to "writeAromaticBondTypes": bond type values 4 through 8 are for SSS queries only,
      * so a 'query file' is created if the container has aromatic bonds and this settings is true.
      */
     private void initIOSettings() {
         forceWriteAs2DCoords = addSetting(new BooleanIOSetting(OptForceWriteAs2DCoordinates, IOSetting.Importance.LOW,
                                                                "Should coordinates always be written as 2D?", "false"));
         writeMajorIsotopes = addSetting(new BooleanIOSetting(OptWriteMajorIsotopes, IOSetting.Importance.LOW,
                                                              "Write atomic mass of any non-null atomic mass including major isotopes (e.g. [12]C)", "true"));
         writeAromaticBondTypes = addSetting(new BooleanIOSetting(OptWriteAromaticBondTypes, IOSetting.Importance.LOW,
                                                                  "Should aromatic bonds be written as bond type 4?", "false"));
         writeQueryFormatValencies = addSetting(new BooleanIOSetting(OptWriteQueryFormatValencies,
                                                                     IOSetting.Importance.LOW, "Should valencies be written in the MDL Query format? (deprecated)", "false"));
         writeDefaultProps = addSetting(new BooleanIOSetting(OptWriteDefaultProperties,
                                                             IOSetting.Importance.LOW,
                                                             "Write trailing zero's on atom/bond property blocks even if they're not used.",
                                                             "true"));
         programNameOpt = addSetting(new StringIOSetting(OptProgramName,
                                                         IOSetting.Importance.LOW,
                                                         "Program name to write at the top of the molfile header, should be exactly 8 characters long",
                                                         "CDK"));
     }
 
     /**
      * Convenience method to set the option for writing aromatic bond types.
      *
      * @param val the value.
      */
     public void setWriteAromaticBondTypes(boolean val) {
         try {
             writeAromaticBondTypes.setSetting(Boolean.toString(val));
         } catch (CDKException e) {
             // ignored can't happen since we are statically typed here
         }
     }
 
     public void customizeJob() {
         for (IOSetting setting : getSettings()) {
             fireIOSettingQuestion(setting);
         }
     }
 
 }
